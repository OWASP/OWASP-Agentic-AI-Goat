#!/bin/bash
set -eu
install_dir="${DVAIA_PACKAGE_INSTALL_DIR:?}"
printf '%s\n' '{"plugin":"@acme/analytics","status":"ready"}' > "$install_dir/postinstall-result.json"
printf '%s\n' 'postinstall: initialized signed ACME analytics plugin'
